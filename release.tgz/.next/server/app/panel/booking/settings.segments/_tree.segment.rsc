:HL["/_next/static/chunks/16hd83qsoy1cc.css","style"]
:HL["/_next/static/media/ec8f59eafded4799-s.p.2avnhkksosb5d.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/f1d25eabcf1db66d-s.p.21se6xk6bxqs6.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
4:[["children",{"s":"__PAGE__","h":162}]]
3:[["children",{"s":"settings","h":98,"c":"$Q4"}]]
2:[["children",{"s":"booking","h":98,"c":"$Q3"}]]
1:[["children",{"s":"panel","h":102,"c":"$Q2"}]]
0:{"b":"6IOQSHv_QQRQmSjTib3KC","t":{"t":{"s":"","h":90,"c":"$Q1"}}}
