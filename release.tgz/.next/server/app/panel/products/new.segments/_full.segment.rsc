1:"$Sreact.fragment"
2:"/_next/static/chunks/1tq6ppe__m8m-.js"
3:I[39756,["$2"],"default"]
4:"/_next/static/chunks/2dthgv2t42miz.js"
5:"/_next/static/chunks/2hrl31401ft05.js"
6:I[58298,["$4","$5"],"default"]
7:I[37457,["$2"],"default"]
8:"/_next/static/chunks/191_5py8gurao.js"
9:I[76001,["$8","$5"],"ErrorScreen"]
c:"LoadingBoundaryProvider"
d:I[39756,["$2"],"$c"]
e:"/_next/static/chunks/328ypm4nzo6si.js"
f:I[73635,["$e"],"ToastProvider"]
10:I[22016,["$e"],""]
11:I[5500,["$e"],"Image"]
12:"$Sreact.suspense"
13:I[8157,["$e"],"PanelSidebarNav"]
15:I[5014,["$e"],"default"]
17:"NotificationBell"
18:I[67661,["$e"],"$17"]
24:"ViewportBoundary"
25:I[97367,["$2"],"$24"]
27:"MetadataBoundary"
28:I[97367,["$2"],"$27"]
2b:I[68027,[],"default",1]
:HL["/_next/static/chunks/16hd83qsoy1cc.css","style"]
:HL["/_next/static/media/ec8f59eafded4799-s.p.2avnhkksosb5d.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/f1d25eabcf1db66d-s.p.21se6xk6bxqs6.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
a:X
1b:X
1e:X
23:X
21:[["children",{"s":"__PAGE__","h":514,"d":{"r":"$L22","p":true,"v":"$23"}}]]
1f:[["children",{"s":"new","h":514,"d":{"r":"$L20","p":true,"v":"$1e"},"c":"$Q21"}]]
1c:[["children",{"s":"products","h":514,"d":{"r":"$L1d","p":true,"v":"$1e"},"c":"$Q1f"}]]
b:[["children",{"s":"panel","h":518,"d":{"r":["$","$Ld",null,{"loading":[["$","div","l",{"className":"flex flex-col gap-6","aria-busy":"true","aria-label":"در حال بارگذاری…","children":[["$","div",null,{"aria-hidden":true,"className":"rounded-md bg-secondary animate-pulse-soft h-8 w-48"}],["$","div",null,{"className":"grid gap-4 sm:grid-cols-2 xl:grid-cols-4","children":[["$","div","0",{"aria-hidden":true,"className":"rounded-md bg-secondary animate-pulse-soft h-28 rounded-surface"}],["$","div","1",{"aria-hidden":true,"className":"rounded-md bg-secondary animate-pulse-soft h-28 rounded-surface"}],["$","div","2",{"aria-hidden":true,"className":"rounded-md bg-secondary animate-pulse-soft h-28 rounded-surface"}],["$","div","3",{"aria-hidden":true,"className":"rounded-md bg-secondary animate-pulse-soft h-28 rounded-surface"}]]}],["$","div",null,{"aria-hidden":true,"className":"rounded-md bg-secondary animate-pulse-soft h-72 rounded-surface"}]]}],[],null],"children":["$","$1","c",{"children":[[["$","script","script-0",{"src":"/_next/static/chunks/328ypm4nzo6si.js","async":true,"nonce":"$undefined"}]],["$","$Lf",null,{"children":["$","div",null,{"className":"flex min-h-dvh flex-1 bg-background","children":[["$","aside",null,{"className":"sticky top-0 hidden h-dvh w-64 shrink-0 flex-col border-e border-border bg-card lg:flex","children":[["$","div",null,{"className":"flex h-16 items-center px-6","children":["$","$L10",null,{"href":"/panel","className":"rounded-md focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring","aria-label":"سپردی، داشبورد","children":[["$","$L11",null,{"src":"/brand/sepordi-wordmark.svg","alt":"سپردی","width":90,"height":28,"priority":true,"unoptimized":true,"className":"shrink-0 sp-logo-on-light"}],["$","$L11",null,{"src":"/brand/sepordi-wordmark-light.svg","alt":"سپردی","width":90,"height":28,"priority":true,"unoptimized":true,"className":"shrink-0 sp-logo-on-dark"}]]}]}],["$","div",null,{"className":"flex-1 overflow-y-auto px-3 py-4","children":["$","$12",null,{"fallback":["$","$L13",null,{}],"children":"$L14"}]}],["$","div",null,{"className":"border-t border-border p-3","children":["$","$L10",null,{"href":"/guide","className":"flex h-11 items-center gap-3 rounded-control px-3 text-muted-foreground hover:bg-secondary hover:text-foreground","children":[["$","$L15",null,{"ref":"$undefined","icon":{"name":"life-buoy","size":24,"node":[["circle",{"cx":"12","cy":"12","r":"10","key":"1mglay"}],["path",{"d":"m4.93 4.93 4.24 4.24","key":"1ymg45"}],["path",{"d":"m14.83 9.17 4.24-4.24","key":"1cb5xl"}],["path",{"d":"m14.83 14.83 4.24 4.24","key":"q42g0n"}],["path",{"d":"m9.17 14.83-4.24 4.24","key":"bqpfvv"}],["circle",{"cx":"12","cy":"12","r":"4","key":"4exip2"}]]},"className":"size-5","strokeWidth":1.5}],"راهنما و پشتیبانی"]}]}]]}],["$","div",null,{"className":"flex min-w-0 flex-1 flex-col","children":[["$","header",null,{"className":"sticky top-0 z-30 flex h-16 items-center gap-3 border-b border-border bg-background/90 px-4 backdrop-blur sm:px-6","children":[["$","$L10",null,{"href":"/panel","className":"lg:hidden","aria-label":"سپردی، داشبورد","children":["$","$L11",null,{"src":"/brand/sepordi-mark.svg","alt":"سپردی","width":25,"height":28,"priority":true,"unoptimized":true,"className":"shrink-0"}]}],["$","div",null,{"className":"flex min-w-0 flex-1 items-center justify-between gap-3","children":["$","$12",null,{"fallback":[["$","div",null,{"aria-hidden":true,"className":"rounded-md bg-secondary animate-pulse-soft h-5 w-32"}],["$","div",null,{"aria-hidden":true,"className":"rounded-md bg-secondary animate-pulse-soft size-9 rounded-full"}]],"children":"$L16"}]}],["$","$L18",null,{"className":"$undefined"}]]}],["$","main",null,{"id":"panel-main","className":"flex-1 px-4 pt-6 pb-24 sm:px-6 lg:px-8 lg:pb-10","children":"$L19"}]]}],"$L1a"]}]}]]}]}],"p":true,"v":"$1b"},"c":"$Q1c"}]]
2a:X
2c:X
2d:X
0:{"P":null,"c":["","panel","products","new"],"q":"","i":false,"t":{"t":{"s":"","h":538,"d":{"r":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/16hd83qsoy1cc.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}]],["$","html",null,{"lang":"fa","dir":"rtl","className":"XvrHAq_variable h-full antialiased","children":["$","body",null,{"className":"flex min-h-full flex-col bg-background font-sans text-foreground","children":["$","$L3",null,{"parallelRouterKey":"children","error":"$6","errorStyles":[],"errorScripts":[["$","script","script-0",{"src":"/_next/static/chunks/2dthgv2t42miz.js","async":true,"nonce":"$undefined"}],["$","script","script-1",{"src":"/_next/static/chunks/2hrl31401ft05.js","async":true,"nonce":"$undefined"}]],"template":["$","$L7",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[["$","$L9",null,{"kind":"404"}],[]],"forbidden":"$undefined","unauthorized":"$undefined"}]}]}]]}],"p":true,"v":"$a"},"c":"$Qb"},"h":{"r":["$","$1","h",{"children":[null,["$","$L25",null,{"children":"$L26"}],["$","$L28",null,{"children":[["$","div",null,{"hidden":true,"children":["$","$12",null,{"name":"Next.Metadata","children":"$L29"}]}],null]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],"p":true,"v":"$2a"}},"m":"$undefined","G":["$2b",[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/16hd83qsoy1cc.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}]]],"S":true,"r":"$2c","s":"$2d","a":"$@2e","l":"$undefined","p":"$undefined","d":"$undefined","b":"6IOQSHv_QQRQmSjTib3KC","u":"$@2f"}
31:I[8157,["$e"],"PanelBottomNav"]
33:"/_next/static/chunks/1vtcod2oarf-w.js"
34:I[82235,["$e","$33"],"ProductForm"]
35:I[82235,["$e","$33"],"EMPTY_DRAFT"]
36:I[97367,["$2"],"OutletBoundary"]
19:["$","div",null,{"className":"mx-auto w-full max-w-7xl","children":["$","$12",null,{"fallback":["$","div",null,{"className":"flex flex-col gap-6","aria-busy":"true","aria-label":"در حال بارگذاری…","children":[["$","div",null,{"aria-hidden":true,"className":"rounded-md bg-secondary animate-pulse-soft h-8 w-48"}],["$","div",null,{"className":"grid gap-4 sm:grid-cols-2 xl:grid-cols-4","children":[["$","div","0",{"aria-hidden":true,"className":"rounded-md bg-secondary animate-pulse-soft h-28 rounded-surface"}],["$","div","1",{"aria-hidden":true,"className":"rounded-md bg-secondary animate-pulse-soft h-28 rounded-surface"}],["$","div","2",{"aria-hidden":true,"className":"rounded-md bg-secondary animate-pulse-soft h-28 rounded-surface"}],["$","div","3",{"aria-hidden":true,"className":"rounded-md bg-secondary animate-pulse-soft h-28 rounded-surface"}]]}],["$","div",null,{"aria-hidden":true,"className":"rounded-md bg-secondary animate-pulse-soft h-72 rounded-surface"}]]}],"children":"$L30"}]}]
1a:["$","$12",null,{"fallback":["$","$L31",null,{}],"children":"$L32"}]
1d:["$","$1","c",{"children":[null,["$","$L3",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L7",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]]}]
20:["$","$1","c",{"children":[null,["$","$L3",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L7",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]]}]
22:["$","$1","c",{"children":[["$","div",null,{"className":"mx-auto flex w-full max-w-4xl flex-col gap-6","children":[["$","div",null,{"className":"flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between","children":[["$","div",null,{"className":"flex flex-col gap-1","children":[["$","h1",null,{"className":"text-2xl font-bold leading-tight","children":"محصول تازه"}],["$","p",null,{"className":"max-w-2xl text-sm leading-7 text-muted-foreground","children":"نام، قیمت و موجودی را بنویسید؛ دستیار از همین اطلاعات به مشتری جواب می‌دهد."}]]}],"$undefined"]}],["$","$L34",null,{"productExt":null,"initial":"$35"}]]}],[["$","script","script-0",{"src":"/_next/static/chunks/1vtcod2oarf-w.js","async":true,"nonce":"$undefined"}]],["$","$L36",null,{"children":["$","$12",null,{"name":"Next.MetadataOutlet","children":"$@37"}]}]]}]
1e:C
2d:300
2f:true
26:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}],["$","meta","2",{"name":"theme-color","content":"#f7f8fc","media":"(prefers-color-scheme: light)"}],["$","meta","3",{"name":"theme-color","content":"#120f24","media":"(prefers-color-scheme: dark)"}]]
38:I[27201,["$2"],"IconMark"]
29:[["$","title","0",{"children":"محصول تازه | پنل سپردی"}],["$","meta","1",{"name":"description","content":"سپردی به پیام مشتری‌های فروشگاه شما در واتس‌اپ، اینستاگرام و تلگرام از روی کاتالوگ خودتان جواب می‌دهد، سفارش ثبت می‌کند و رسید کارت‌به‌کارت را برای تأیید شما کنار می‌گذارد."}],["$","meta","2",{"name":"application-name","content":"سپردی"}],["$","link","3",{"rel":"manifest","href":"/manifest.webmanifest","crossOrigin":"$undefined"}],["$","meta","4",{"name":"robots","content":"noindex, nofollow"}],["$","meta","5",{"property":"og:title","content":"محصول تازه | پنل سپردی"}],["$","meta","6",{"property":"og:description","content":"سپردی به پیام مشتری‌های فروشگاه شما در واتس‌اپ، اینستاگرام و تلگرام از روی کاتالوگ خودتان جواب می‌دهد، سفارش ثبت می‌کند و رسید کارت‌به‌کارت را برای تأیید شما کنار می‌گذارد."}],["$","meta","7",{"property":"og:site_name","content":"سپردی"}],["$","meta","8",{"property":"og:locale","content":"fa_IR"}],["$","meta","9",{"property":"og:image","content":"https://sepordi.ir/opengraph-image?4b8ec9afca33f59c"}],["$","meta","10",{"property":"og:image:type","content":"image/png"}],["$","meta","11",{"property":"og:image:width","content":"1200"}],["$","meta","12",{"property":"og:image:height","content":"630"}],["$","meta","13",{"property":"og:image:alt","content":"سپردی، دستیار هوشمند فروش در واتس‌اپ، اینستاگرام و تلگرام"}],["$","meta","14",{"property":"og:type","content":"website"}],["$","meta","15",{"name":"twitter:card","content":"summary_large_image"}],["$","meta","16",{"name":"twitter:title","content":"محصول تازه | پنل سپردی"}],["$","meta","17",{"name":"twitter:description","content":"سپردی به پیام مشتری‌های فروشگاه شما در واتس‌اپ، اینستاگرام و تلگرام از روی کاتالوگ خودتان جواب می‌دهد، سفارش ثبت می‌کند و رسید کارت‌به‌کارت را برای تأیید شما کنار می‌گذارد."}],["$","meta","18",{"name":"twitter:image","content":"https://sepordi.ir/opengraph-image?4b8ec9afca33f59c"}],["$","meta","19",{"name":"twitter:image:alt","content":"سپردی، دستیار هوشمند فروش در واتس‌اپ، اینستاگرام و تلگرام"}],["$","meta","20",{"name":"twitter:image:type","content":"image/png"}],["$","meta","21",{"name":"twitter:image:width","content":"1200"}],["$","meta","22",{"name":"twitter:image:height","content":"630"}],["$","link","23",{"rel":"icon","href":"/favicon.ico?favicon.1h03watn4abxl.ico","sizes":"48x48","type":"image/x-icon"}],["$","link","24",{"rel":"icon","href":"/icon.png?icon.038nhxl31vg96.png","sizes":"512x512","type":"image/png"}],["$","link","25",{"rel":"apple-touch-icon","href":"/apple-icon.png?apple-icon.14u69sbf41v-m.png","sizes":"180x180","type":"image/png"}],["$","$L38","26",{}]]
37:null
2d:C
2a:C
2c:C
23:C
1b:C
a:C
2e:null
