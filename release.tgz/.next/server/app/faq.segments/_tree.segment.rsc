:HL["/_next/static/chunks/16hd83qsoy1cc.css","style"]
:HL["/_next/static/media/ec8f59eafded4799-s.p.2avnhkksosb5d.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/f1d25eabcf1db66d-s.p.21se6xk6bxqs6.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
3:[["children",{"s":"__PAGE__","h":49314}]]
2:[["children",{"s":"faq","h":49250,"c":"$Q3"}]]
1:[["children",{"s":"(marketing)","h":49250,"c":"$Q2"}]]
0:{"b":"6IOQSHv_QQRQmSjTib3KC","t":{"t":{"s":"","h":49234,"c":"$Q1"}}}
