var R=require("../../chunks/[turbopack]_runtime.js")("server/app/manifest.webmanifest/route.js")
R.c("server/chunks/[externals]__0pzu9hy0zcsgs._.js")
R.c("server/chunks/node_modules_next_dist_16uekqf-emgzs._.js")
R.c("server/chunks/node_modules_next_0sx6ib_cz483a._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5yieigz._.js")
R.c("server/chunks/_1ds4d2syxzvn2._.js")
R.c("server/chunks/_next-internal_server_app_manifest_webmanifest_route_actions_08hcpz02cjxld.js")
R.m(22945)
module.exports=R.m(22945).exports
