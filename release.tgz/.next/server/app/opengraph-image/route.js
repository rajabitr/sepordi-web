var R=require("../../chunks/[turbopack]_runtime.js")("server/app/opengraph-image/route.js")
R.c("server/chunks/[externals]_next_dist_compiled_@vercel_og_index_node_0_3_o0a3fwvz7.js")
R.c("server/chunks/[root-of-the-server]__15f6s51g1tv49._.js")
R.c("server/chunks/node_modules_next_0sx6ib_cz483a._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5yieigz._.js")
R.c("server/chunks/_0mgqihazur3so._.js")
R.c("server/chunks/_next-internal_server_app_opengraph-image_route_actions_1n32_cshpygg5.js")
R.m(9191)
module.exports=R.m(9191).exports
