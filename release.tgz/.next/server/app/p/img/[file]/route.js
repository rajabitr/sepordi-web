var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/p/img/[file]/route.js")
R.c("server/chunks/[externals]__0-9e4i8l4lwmn._.js")
R.c("server/chunks/src_server_product-images_store_ts_1ugh6qmfcwvw1._.js")
R.c("server/chunks/_0b2xh535qx2u7._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5yieigz._.js")
R.c("server/chunks/_next-internal_server_app_p_img_[file]_route_actions_0w4a5uvyfb-3f.js")
R.m(87566)
module.exports=R.m(87566).exports
