var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/payments/zarinpal/callback/route.js")
R.c("server/chunks/[root-of-the-server]__0f_cxi9-ryg7q._.js")
R.c("server/chunks/src_server_db_repo_ts_1zh7kbcxz6rdk._.js")
R.c("server/chunks/_01apdh0rxi-g8._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5yieigz._.js")
R.c("server/chunks/1oeh_server_app_api_payments_zarinpal_callback_route_actions_0z-pexxpiabc2.js")
R.m(87985)
module.exports=R.m(87985).exports
