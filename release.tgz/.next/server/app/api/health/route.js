var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/health/route.js")
R.c("server/chunks/[externals]__15feieidlnnli._.js")
R.c("server/chunks/_1y5_49ip8l9oe._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5yieigz._.js")
R.c("server/chunks/node_modules_next_0sx6ib_cz483a._.js")
R.c("server/chunks/_next-internal_server_app_api_health_route_actions_1ryftkbeskq31.js")
R.m(43007)
module.exports=R.m(43007).exports
