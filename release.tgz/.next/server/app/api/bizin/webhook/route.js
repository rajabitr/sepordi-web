var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/bizin/webhook/route.js")
R.c("server/chunks/[root-of-the-server]__02xt05-hvm-z8._.js")
R.c("server/chunks/src_server_db_repo_ts_1zh7kbcxz6rdk._.js")
R.c("server/chunks/_0m7ra5up81ncz._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5yieigz._.js")
R.c("server/chunks/_next-internal_server_app_api_bizin_webhook_route_actions_1kclrmmh0w01k.js")
R.m(22709)
module.exports=R.m(22709).exports
