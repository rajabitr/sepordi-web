module.exports=[89667,e=>{e.v(_=>Promise.all(["server/chunks/[externals]_node_zlib_15_uv03miudih._.js","server/chunks/src_server_bizin_mock_index_ts_07mz-32_c9mxl._.js"].map(_=>e.l(_))).then(()=>_(35688)))}];

//# sourceMappingURL=src_server_bizin_mock_index_ts_1bsbkv_vf7_64._.js.map