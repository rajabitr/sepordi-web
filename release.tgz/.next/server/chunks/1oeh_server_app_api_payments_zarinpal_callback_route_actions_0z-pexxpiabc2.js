module.exports=[10288,(e,o,d)=>{}];

//# sourceMappingURL=1oeh_server_app_api_payments_zarinpal_callback_route_actions_0z-pexxpiabc2.js.map