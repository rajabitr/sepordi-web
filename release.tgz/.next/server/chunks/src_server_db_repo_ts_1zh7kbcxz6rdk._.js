module.exports=[53427,12754,e=>{"use strict";e.i(66680);var E=e.i(2157),s=e.i(50227),T=e.x("node:sqlite",()=>require("node:sqlite"),!0);let r=[{id:1,name:"initial",sql:`
      CREATE TABLE users (
        id            TEXT PRIMARY KEY,
        phone         TEXT NOT NULL UNIQUE,
        email         TEXT,
        display_name  TEXT NOT NULL,
        password_hash TEXT,
        role          TEXT NOT NULL DEFAULT 'seller' CHECK (role IN ('seller', 'admin')),
        created_at    TEXT NOT NULL
      );
      CREATE UNIQUE INDEX users_email ON users (email) WHERE email IS NOT NULL;

      CREATE TABLE sessions (
        token_hash TEXT PRIMARY KEY,
        user_id    TEXT NOT NULL REFERENCES users (id) ON DELETE CASCADE,
        expires_at TEXT NOT NULL,
        created_at TEXT NOT NULL,
        ua         TEXT
      );
      CREATE INDEX sessions_user ON sessions (user_id);

      CREATE TABLE otp_codes (
        phone      TEXT PRIMARY KEY,
        code_hash  TEXT NOT NULL,
        expires_at TEXT NOT NULL,
        attempts   INTEGER NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL
      );

      CREATE TABLE shops (
        id                   TEXT PRIMARY KEY,
        user_id              TEXT NOT NULL REFERENCES users (id) ON DELETE CASCADE,
        external_business_id TEXT NOT NULL UNIQUE,
        name                 TEXT NOT NULL,
        bizin_tenant_id      TEXT,
        created_at           TEXT NOT NULL
      );
      CREATE INDEX shops_user ON shops (user_id);

      CREATE TABLE webhook_events (
        event_id    TEXT PRIMARY KEY,
        type        TEXT NOT NULL,
        ext         TEXT,
        payload     TEXT NOT NULL,
        received_at TEXT NOT NULL,
        read_at     TEXT
      );
      CREATE INDEX webhook_events_ext ON webhook_events (ext, received_at);

      CREATE TABLE credit_orders (
        id           TEXT PRIMARY KEY,
        shop_id      TEXT NOT NULL REFERENCES shops (id) ON DELETE CASCADE,
        plan_code    TEXT NOT NULL,
        amount_toman INTEGER NOT NULL CHECK (amount_toman > 0),
        status       TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'paid', 'failed', 'cancelled')),
        method       TEXT NOT NULL,
        ref          TEXT,
        created_at   TEXT NOT NULL
      );
      CREATE INDEX credit_orders_shop ON credit_orders (shop_id, created_at);

      CREATE TABLE settings (
        key   TEXT PRIMARY KEY,
        value TEXT NOT NULL
      );
    `},{id:2,name:"credit_orders_lifecycle",sql:`
      DROP TABLE IF EXISTS credit_order_meta;
      DROP TABLE credit_orders;

      CREATE TABLE credit_orders (
        id           TEXT PRIMARY KEY,
        shop_id      TEXT NOT NULL REFERENCES shops (id) ON DELETE CASCADE,
        plan_code    TEXT NOT NULL,
        amount_toman INTEGER NOT NULL CHECK (amount_toman > 0),
        amount_rial  INTEGER NOT NULL CHECK (amount_rial = amount_toman * 10),
        status       TEXT NOT NULL DEFAULT 'pending'
                     CHECK (status IN ('pending', 'paid', 'granted', 'rejected', 'failed', 'cancelled')),
        method       TEXT NOT NULL CHECK (method IN ('zarinpal', 'card_to_card')),
        ref          TEXT,
        authority    TEXT UNIQUE,
        created_at   TEXT NOT NULL,
        verified_at  TEXT,
        granted_at   TEXT,
        reviewed_by  TEXT,
        review_note  TEXT,
        reviewed_at  TEXT,
        CHECK (status NOT IN ('paid', 'granted') OR verified_at IS NOT NULL),
        CHECK (status <> 'granted' OR granted_at IS NOT NULL),
        CHECK (status <> 'rejected' OR (review_note IS NOT NULL AND review_note <> ''))
      );
      CREATE INDEX credit_orders_shop ON credit_orders (shop_id, created_at);
      CREATE INDEX credit_orders_status ON credit_orders (status, created_at);
    `},{id:3,name:"shop_team",sql:`
      CREATE TABLE shop_members (
        shop_id    TEXT NOT NULL REFERENCES shops (id) ON DELETE CASCADE,
        user_id    TEXT NOT NULL REFERENCES users (id) ON DELETE CASCADE,
        role       TEXT NOT NULL CHECK (role IN ('owner', 'agent')),
        created_at TEXT NOT NULL,
        UNIQUE (shop_id, user_id)
      );
      CREATE INDEX shop_members_user ON shop_members (user_id, created_at);

      INSERT OR IGNORE INTO shop_members (shop_id, user_id, role, created_at)
        SELECT id, user_id, 'owner', created_at FROM shops;

      CREATE TRIGGER shops_creator_is_owner AFTER INSERT ON shops
      BEGIN
        INSERT OR IGNORE INTO shop_members (shop_id, user_id, role, created_at) VALUES (NEW.id, NEW.user_id, 'owner', NEW.created_at);
      END;

      CREATE TABLE shop_invites (
        id          TEXT PRIMARY KEY,
        shop_id     TEXT NOT NULL REFERENCES shops (id) ON DELETE CASCADE,
        phone       TEXT NOT NULL,
        role        TEXT NOT NULL CHECK (role IN ('owner', 'agent')),
        invited_by  TEXT REFERENCES users (id) ON DELETE SET NULL,
        created_at  TEXT NOT NULL,
        accepted_at TEXT
      );
      CREATE UNIQUE INDEX shop_invites_pending ON shop_invites (shop_id, phone) WHERE accepted_at IS NULL;
      CREATE INDEX shop_invites_phone ON shop_invites (phone, created_at) WHERE accepted_at IS NULL;
    `},{id:4,name:"member_role_presets",sql:`
      DROP TRIGGER shops_creator_is_owner;

      ALTER TABLE shop_members RENAME TO shop_members_v3;
      CREATE TABLE shop_members (
        shop_id    TEXT NOT NULL REFERENCES shops (id) ON DELETE CASCADE,
        user_id    TEXT NOT NULL REFERENCES users (id) ON DELETE CASCADE,
        role       TEXT NOT NULL CHECK (role IN ('owner', 'agent', 'responder', 'finance', 'fulfillment')),
        created_at TEXT NOT NULL,
        UNIQUE (shop_id, user_id)
      );
      INSERT INTO shop_members (shop_id, user_id, role, created_at) SELECT shop_id, user_id, role, created_at FROM shop_members_v3;
      DROP TABLE shop_members_v3;
      CREATE INDEX shop_members_user ON shop_members (user_id, created_at);

      CREATE TRIGGER shops_creator_is_owner AFTER INSERT ON shops
      BEGIN
        INSERT OR IGNORE INTO shop_members (shop_id, user_id, role, created_at) VALUES (NEW.id, NEW.user_id, 'owner', NEW.created_at);
      END;

      ALTER TABLE shop_invites RENAME TO shop_invites_v3;
      CREATE TABLE shop_invites (
        id          TEXT PRIMARY KEY,
        shop_id     TEXT NOT NULL REFERENCES shops (id) ON DELETE CASCADE,
        phone       TEXT NOT NULL,
        role        TEXT NOT NULL CHECK (role IN ('owner', 'agent', 'responder', 'finance', 'fulfillment')),
        invited_by  TEXT REFERENCES users (id) ON DELETE SET NULL,
        created_at  TEXT NOT NULL,
        accepted_at TEXT
      );
      INSERT INTO shop_invites SELECT id, shop_id, phone, role, invited_by, created_at, accepted_at FROM shop_invites_v3;
      DROP TABLE shop_invites_v3;
      CREATE UNIQUE INDEX shop_invites_pending ON shop_invites (shop_id, phone) WHERE accepted_at IS NULL;
      CREATE INDEX shop_invites_phone ON shop_invites (phone, created_at) WHERE accepted_at IS NULL;
    `},{id:5,name:"session_current_shop",sql:"ALTER TABLE sessions ADD COLUMN shop_id TEXT REFERENCES shops (id) ON DELETE SET NULL;"},{id:6,name:"two_step_login",sql:`
      CREATE TABLE user_totp (
        user_id    TEXT PRIMARY KEY REFERENCES users (id) ON DELETE CASCADE,
        secret_enc TEXT NOT NULL,
        enabled_at TEXT,
        last_step  INTEGER NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL
      );

      CREATE TABLE user_recovery_codes (
        user_id    TEXT NOT NULL REFERENCES users (id) ON DELETE CASCADE,
        code_hash  TEXT NOT NULL,
        used_at    TEXT,
        created_at TEXT NOT NULL,
        PRIMARY KEY (user_id, code_hash)
      );

      CREATE TABLE login_challenges (
        token_hash TEXT PRIMARY KEY,
        user_id    TEXT NOT NULL REFERENCES users (id) ON DELETE CASCADE,
        expires_at TEXT NOT NULL,
        attempts   INTEGER NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL
      );
      CREATE INDEX login_challenges_user ON login_challenges (user_id);
    `},{id:7,name:"activity_log",sql:`
      CREATE TABLE activity_log (
        id          TEXT PRIMARY KEY,
        shop_id     TEXT NOT NULL REFERENCES shops (id) ON DELETE CASCADE,
        user_id     TEXT REFERENCES users (id) ON DELETE SET NULL,
        action      TEXT NOT NULL,
        target_type TEXT,
        target_id   TEXT,
        meta        TEXT CHECK (meta IS NULL OR json_valid(meta)),
        created_at  TEXT NOT NULL
      );
      CREATE INDEX activity_log_shop ON activity_log (shop_id, created_at);
    `}];e.i(46472).Y[0];let t=Symbol.for("sepordi.db");function N(){let e=globalThis;if(!e[t]){var N;let a;e[t]=(":memory:"!==(N=process.env.SEPORDI_DB_PATH||"./data/sepordi.db")&&(0,E.mkdirSync)(s.default.dirname(s.default.resolve(N)),{recursive:!0}),(a=new T.DatabaseSync(N)).exec("PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON; PRAGMA busy_timeout = 5000;"),!function(e){e.exec("CREATE TABLE IF NOT EXISTS schema_migrations (id INTEGER PRIMARY KEY, name TEXT NOT NULL, applied_at TEXT NOT NULL)");let E=new Set(e.prepare("SELECT id FROM schema_migrations").all().map(e=>e.id)),s=[];for(let T of[...r].sort((e,E)=>e.id-E.id))if(!E.has(T.id)){e.exec("BEGIN IMMEDIATE");try{e.exec(T.sql),e.prepare("INSERT INTO schema_migrations (id, name, applied_at) VALUES (?, ?, ?)").run(T.id,T.name,new Date().toISOString()),e.exec("COMMIT"),s.push(T.id)}catch(E){throw e.exec("ROLLBACK"),E}}}(a),a),e[t]}return e[t]}e.s(["f",0,N],12754);let a=()=>new Date().toISOString(),i={create(e,E,s,T){N().prepare("INSERT INTO sessions (token_hash, user_id, expires_at, created_at, ua) VALUES (?, ?, ?, ?, ?)").run(e,E,s.toISOString(),a(),T)},userFor:e=>i.lookup(e)?.user,lookup(e){let E=N().prepare("SELECT u.*, s.shop_id AS session_shop_id FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.token_hash = ? AND s.expires_at > ?").get(e,a());if(!E)return;let{session_shop_id:s,...T}=E;return{user:T,shopId:s}},setShop(e,E){N().prepare("UPDATE sessions SET shop_id = ? WHERE token_hash = ?").run(E,e)},listForUser:e=>N().prepare("SELECT token_hash, created_at, expires_at, ua FROM sessions WHERE user_id = ? AND expires_at > ? ORDER BY created_at DESC").all(e,a()),deleteOthersForUser:(e,E)=>Number(N().prepare("DELETE FROM sessions WHERE user_id = ? AND token_hash <> ?").run(e,E).changes),delete(e){N().prepare("DELETE FROM sessions WHERE token_hash = ?").run(e)},deleteForUser(e){N().prepare("DELETE FROM sessions WHERE user_id = ?").run(e)},purgeExpired(){N().prepare("DELETE FROM sessions WHERE expires_at <= ?").run(a())}},_={shopFor(e,E){let s=_.shopsFor(e);return(E?s.find(e=>e.shop.id===E):void 0)??s[0]},shopsFor:e=>N().prepare("SELECT s.*, m.role AS member_role FROM shop_members m JOIN shops s ON s.id = m.shop_id WHERE m.user_id = ? ORDER BY m.created_at, s.created_at").all(e).map(({member_role:e,...E})=>({shop:E,role:e})),get:(e,E)=>N().prepare("SELECT * FROM shop_members WHERE shop_id = ? AND user_id = ?").get(e,E),list:e=>N().prepare("SELECT m.*, u.phone, u.display_name FROM shop_members m JOIN users u ON u.id = m.user_id WHERE m.shop_id = ? ORDER BY m.role <> 'owner', m.created_at").all(e),add(e,E,s){N().prepare("INSERT INTO shop_members (shop_id, user_id, role, created_at) VALUES (?, ?, ?, ?)").run(e,E,s,a())},setRole:(e,E,s)=>1===Number(N().prepare("UPDATE shop_members SET role = ? WHERE shop_id = ? AND user_id = ?").run(s,e,E).changes),remove:(e,E)=>1===Number(N().prepare("DELETE FROM shop_members WHERE shop_id = ? AND user_id = ?").run(e,E).changes),ownerCount:e=>Number(N().prepare("SELECT COUNT(*) AS n FROM shop_members WHERE shop_id = ? AND role = 'owner'").get(e).n)};e.s(["w",0,_,"X",0,i,"c",0,{get(e){let E=N().prepare("SELECT value FROM settings WHERE key = ?").get(e);return E?JSON.parse(E.value):void 0},set(e,E){N().prepare("INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT (key) DO UPDATE SET value = excluded.value").run(e,JSON.stringify(E))}},"T",0,{insertIfNew:e=>1===Number(N().prepare("INSERT OR IGNORE INTO webhook_events (event_id, type, ext, payload, received_at) VALUES (?, ?, ?, ?, ?)").run(e.eventId,e.type,e.ext,e.payload,a()).changes),recentForExt:(e,E=30)=>N().prepare("SELECT * FROM webhook_events WHERE ext = ? ORDER BY received_at DESC LIMIT ?").all(e,E),unreadCount:e=>Number(N().prepare("SELECT COUNT(*) AS n FROM webhook_events WHERE ext = ? AND read_at IS NULL").get(e).n),markAllRead(e){N().prepare("UPDATE webhook_events SET read_at = ? WHERE ext = ? AND read_at IS NULL").run(a(),e)},purgeOlderThan(e){N().prepare("DELETE FROM webhook_events WHERE received_at < ?").run(e)}}],53427)}];

//# sourceMappingURL=src_server_db_repo_ts_1zh7kbcxz6rdk._.js.map