module.exports=[76498,(e,o,d)=>{}];

//# sourceMappingURL=1jng_app_panel_inbox_data_conversations_%5Bid%5D_messages_route_actions_0s9g7bgngew9i.js.map