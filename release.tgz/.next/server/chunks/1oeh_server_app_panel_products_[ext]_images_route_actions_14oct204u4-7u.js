module.exports=[21010,(e,o,d)=>{}];

//# sourceMappingURL=1oeh_server_app_panel_products_%5Bext%5D_images_route_actions_14oct204u4-7u.js.map